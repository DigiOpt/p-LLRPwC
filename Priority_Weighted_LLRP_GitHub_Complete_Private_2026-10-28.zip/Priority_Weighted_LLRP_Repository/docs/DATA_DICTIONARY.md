# Data dictionary and directory provenance

| Location | Contents | Purpose |
|---|---|---|
| `Inputs/{City}_index_map.xlsx` | Coordinates, customer/warehouse codes, annual sales, realized priority profiles, candidate depot records and operational parameters | Build network, demands and priority weights |
| `Inputs/{City}_distance_matrix_Google.xlsx` | Directed road-distance matrix (source units: inspect workbook) | Financial travel cost in km |
| `Inputs/{City}_duration_matrix_Google.xlsx` | Directed travel times | Pharmacy arrival times and complete route-duration checks in seconds |
| `Outputs/{City}[_Profile]_Tcheby_Anchor_Validation_parallel.xlsx` | `Summary`, `Payoff_Table`, `Anchor_Routes`, `Run_Level` | 30-run financial and latency anchor modes, reference pairs and routes |
| `Outputs/Tcheby_Production/{City}_{Profile}_Tcheby_Production.xlsx` | `Summary`, `Best_By_Lambda`, `Run_Level` | 30 runs per non-endpoint lambda and best obtained point |
| `Outputs/Tcheby_Production/*_Curve.csv` | CSV version of the per-lambda preference-path table | Compact machine-readable Pareto analysis |
| `Outputs/Routing_Cost_Analysis/{City}/*` | Profile-specific/aggregated routing travel-cost decompositions and solution routes | Service-priority and travel-cost comparisons |
| `benchmarks/instances/dat` | Original Barreto benchmark .dat files, transported byte-for-byte | Benchmark instance inputs |
| `benchmarks/results/extended` and `/baseline` | 10 instance-specific merged run workbooks each | Benchmark 30-run records and method comparison |
| `benchmarks/ablation` | Code/summary for additional search configurations | Table 4 and Appendix I |
| `docs/current_manuscript.pdf` | User-supplied current 26-page manuscript | Authoritative definition of reported claims |

**Caution:** Raw `Inputs/*index_map.xlsx` contain identifiable geospatial/customer identifiers and business sales. Do not upload these unmodified files to a public repository before a confidentiality/redistribution review. A private repository can preserve full reproducibility without automatic public disclosure.

Original source: user-provided Google Drive root folder `https://drive.google.com/drive/folders/1w88w4D4t4vAnMDXtcvXqb8enVs8M991L`, primarily `Chebyshev/{Inputs,Anchors,Chebyshev Results,Codes}`, `LRP INSTANCES`, and `LRP INSTANCES/LLRP RESULTS`. Locally created metadata/CSV checks are identified as derived artifacts, not original experiment data. Every included artifact has a SHA-256 hash in `MANIFEST_SHA256.csv`.
