# License and redistribution status

No open-source software license, data license, or permission to redistribute individual pharmacy records was supplied with the source material. This archive **does not grant permission** for third-party redistribution, reuse or modification.

Before publishing a public GitHub repository, the rights holders should select a software license and separately confirm data rights, provider-specific conditions for Google-derived road matrices, and consent/confidentiality rules governing coordinates, customer identifiers and sales. A private repository with controlled access is the recommended interim destination for the complete reproducibility archive.
