# Bi-objective Priority-Weighted Latency Location-Routing (Pharmaceutical Distribution)

**Reproducibility archive for:** *A Bi-objective Priority-Weighted Latency Location-Routing Problem for Pharmaceutical Distribution* — Alperen Bal, Michele Cedolin, Ethem Çanakoğlu (user-supplied 26-page manuscript). Code and data were selected to match this **four-city** manuscript, not the older six-city study in the shared Drive.

> **Important before posting on GitHub:** This is the **complete research/private reproducibility version**, not a public-cleared dataset. `Inputs/*index_map.xlsx` contain real coordinates, pharmacy/customer identifiers and commercial sales; the road matrices may be subject to third-party data terms. **Use a private GitHub repository unless publication rights, redaction and provider conditions have been verified.** See `LICENSE_NOTICE.md`.

## Research question

The study optimizes integrated depot selection and vehicle routes for pharmacy replenishment while balancing financial distribution cost (`CF`) against pharmacy-priority-weighted customer arrival time (`P`). It uses **GRASP-VND-SO** (Extended Clarke–Wright savings, seven VND route neighborhoods, depot replacement, temporary vehicle-capacity oscillation) and anchor-normalized augmented weighted **Tchebycheff** scalarization (`rho = 1e-4`) to explore supported and unsupported trade-offs.

## What is in this repository?

```text
.
├── README.md                       this guide
├── LICENSE_NOTICE.md              redistribution restrictions / licensing status
├── CITATION.cff                    bibliographic metadata (no DOI invented)
├── requirements.txt               reproducibility-oriented dependencies
├── code/
│   ├── LLRP_CORE_PARALLEL_HPC.py   main research heuristic and data loaders
│   ├── RUN_TCHEBY_ANCHORS_HPC_PARALLEL.py
│   ├── RUN_TCHEBY_ANCHORS_PROFILE_HPC_PARALLEL.py
│   ├── RUN_TCHEBY_PRODUCTION_PARALLEL.py
│   └── legacy_reference/          earlier code snapshot (not the default)
├── Inputs/                         4 cities × [index, distance, duration]
├── Outputs/
│   ├── *_Anchor_Validation_parallel.xlsx       4 × 5 stored anchors
│   ├── Tcheby_Production/           20 stored profile workbooks + 20 curves
│   └── Routing_Cost_Analysis/       route/cost breakdown by city and priority
├── benchmarks/
│   ├── instances/                   Barreto .dat files and source workbooks
│   ├── code/                        benchmark-only VND variants
│   ├── results/{baseline,extended,summary}/
│   └── ablation/                    four-configuration audit and supporting output
├── tools/
│   ├── check_package.py            file/data/run-count audit (fast)
│   └── rebuild_tables.py           derive portable CSV summaries (fast)
├── derived_tables/                 output of rebuild_tables.py
├── docs/                           model/experiment/data/audit notes + PDF
└── MANIFEST_SHA256.csv             per-file integrity hashes
```

## Setup (recommended Python 3.9–3.12)

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python tools/check_package.py
python tools/verify_manifest.py
python tools/rebuild_tables.py
```

The audit and summary commands inspect the already stored results **without rerunning the optimization**. `derived_tables/` contains machine-readable checks and normalized comparisons to support tables and figures. These fast scripts are useful on a laptop.

## Rerun cost and latency anchor modes (CPU intensive)

Run all examples from the **repository root**. The original research scripts expect `Inputs/` and `Outputs/` relative to the current working directory and intentionally preserve those conventions. The scripts may write over existing output files; run them on a copy or with backup files when retaining original experimental results.

```bash
# Windows PowerShell (set environment variables with $env:CITY / $env:PROFILE)
# Linux/macOS:
CITY=Afyon WORKERS=4 python code/RUN_TCHEBY_ANCHORS_HPC_PARALLEL.py
CITY=Afyon PROFILE=Tiered WORKERS=4 python code/RUN_TCHEBY_ANCHORS_PROFILE_HPC_PARALLEL.py
```

The common Equal-Priority anchor filename is `Outputs/{City}_Tcheby_Anchor_Validation_parallel.xlsx`; named-profile anchors are stored as `Outputs/{City}_{Profile}_Tcheby_Anchor_Validation_parallel.xlsx`. These are read by the production runner to normalize financial cost and priority-weighted latency.

## Rerun an interior Tchebycheff preference set (CPU intensive)

After producing/retaining both anchors for the intended city/profile:

```bash
CITY=Afyon PROFILE=Equal-Priority MAX_ITER=50 N_SEEDS=30 WORKERS=16 RHO=0.0001 \
  python code/RUN_TCHEBY_PRODUCTION_PARALLEL.py
```

Use `CITY=Isparta` for the largest city. Only the five published interior preferences (`0.1,0.3,0.5,0.7,0.9`) are executed for Isparta in the **publication-aligned runner supplied here**; the other three cities use nine values (`0.1` through `0.9`). **Traceability notice:** the original production runner obtained from Drive used nine interior values for every city, inconsistent with the five Isparta values in the stored output workbooks. We added an explicit Isparta branch to the main runner while preserving the original unmodified source under `code/legacy_reference/RUN_TCHEBY_PRODUCTION_PARALLEL_original.py`. See `docs/REPRODUCIBILITY_LIMITS.md`. A quick smoke run is possible with `MAX_ITER=1 N_SEEDS=1 WORKERS=1`, but it is **not** the published experimental design. The production runner expects compatible exact filenames for anchor workbooks and exports `Best_By_Lambda`, `Run_Level` and curves under `Outputs/Tcheby_Production/`.

## How to locate the results in the paper

| Manuscript result | Source of record in this archive |
|---|---|
| Table 2 and Table 3: 10 benchmark cases | `benchmarks/results/extended/` (10 merged 30-run workbooks), `benchmarks/results/summary/VNDZou.xlsx` |
| Table 4, Appendix I: component ablation | `benchmarks/ablation/analysis/ablation_instance.csv` and `ablation_summary.csv`; method code in `benchmarks/code/` |
| Table 5: four-city characteristics | `Inputs/` and `docs/EXPERIMENT_DESIGN.md` |
| Table 6/7: exact validation | Manuscript PDF only for exact comparisons (exact code intentionally omitted) |
| Table 8 and Appendix K: cost–latency paths | `Outputs/Routing_Cost_Analysis/{City}/*All_Profiles*` and `Outputs/Tcheby_Production/` |
| Priority profiles, depot switching and robustness | Individual `Outputs/*Anchor*`, `Outputs/Tcheby_Production/*`, routing workbooks and 30-run benchmark records |

### Interpretation traps

- Financial cost includes `5000*Ng + 200*k` in the case studies; travel cost is only the distance-dependent portion (`CF - fixed charges`).
- Return-to-depot time **counts** toward route duration but **does not count** toward latency.
- Priorities are **scenario policy weights**, not clinically validated urgent-care classes.
- Trade-off points may be duplicate or heuristic-dominated. Exclude dominated points when drawing empirical Pareto fronts and distinguish exact/heuristic anchors.
- Aydin has a heuristic cost anchor that the manuscript reports is not globally optimal; normalized cost for some solutions can be negative.
- Fixed stochastic seeds are in stored worksheets and the original scripts; full stochastic bit-for-bit reproducibility depends on execution environment.

## Scope, attribution and limitations

The complete package contains only the **heuristic** source code, manuscript-aligned input files, available stored heuristic run outputs, benchmark source data and relevant descriptive analyses. It **does not** include the priority-flow exact MIP, branch-and-price source, Gurobi solver files or exact solver logs. Formal problem formulations and the comparison values reported by the authors remain in `docs/current_manuscript.pdf`. For reproducibility boundaries see `docs/REPRODUCIBILITY_LIMITS.md`.

**Source provenance:** user-provided Google Drive folder `https://drive.google.com/drive/folders/1w88w4D4t4vAnMDXtcvXqb8enVs8M991L` (subfolders `Chebyshev`, `LRP INSTANCES`); source files were copied into a deterministic folder layout. A SHA-256 manifest enumerates included bytes. This repository has not been published to GitHub.

## Verification notes

An automated GitHub Actions workflow (`.github/workflows/validate.yml`) checks the source/data inventory, verifies the frozen SHA-256 manifest, and tests two mathematical invariants. It does **not** rerun the expensive GRASP experiments or assert exact optimality. Derived CSV summaries already included in `derived_tables/` can be regenerated with `python tools/rebuild_tables.py`.
